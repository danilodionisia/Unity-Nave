﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //public float speed = 5;

   // void FixedUpdate()  //devemos usar FixedUpdate sempre que formos alterar coisas relativas a fisica do jogo
    //{
        //float h = Input.GetAxisRaw("Horizontal");
       // float v = Input.GetAxisRaw("Vertical");

       // Vector2 direction = new Vector2(h, v);
       // GetComponent<Rigidbody2D>().velocity = direction.normalized * speed;

       
    //}

    void Update()
    {
        if (Input.GetAxis("Horizontal") > 0)
        {
            transform.Translate(Vector2.right * 0.05f);
        }

        if (Input.GetAxis("Horizontal") < 0)
        {
            transform.Translate(Vector2.left * 0.05f);
        }

        if (Input.GetAxis("Vertical") > 0)
        {
            transform.Translate(Vector2.up * 0.05f);
        }

        if (Input.GetAxis("Vertical") < 0)
        {
            transform.Translate(Vector2.down * 0.05f);
        }
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "enemy")
        {
            Destroy(collision.gameObject);
            Life.life = Life.life - 1;
        }

        if(collision.gameObject.tag == "bulletenemy")
        {
            Life.life = Life.life - 1;

        }

       

    }

    public void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.tag == "bulletenemy")
        {
            Life.life = Life.life - 1;

        }
    }
    }
