﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    public GameObject ship; //variavel para o ship inimigo
    public float interval = 6; //variavel para o intervalo que será criado o inimigo

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("NextShip", interval, interval); //função de loop de spawn
    }

    void NextShip()
    {
        Instantiate(ship, transform.position, Quaternion.identity);
    }
}
