﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletEnemy : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D collision)
    {


        if (collision.gameObject.name != "Background")
        {
            if(collision.gameObject.name == "PlayerShip")
            Destroy(gameObject);
        }



    }
    
}
