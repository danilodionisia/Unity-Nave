﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UVScroll : MonoBehaviour
{
    public Vector2 speed;  //variavel para alterar velocidade de rolagem do plano de fundo,tanto no eixo x como o y

    void LateUpdate()
    {
        GetComponent<Renderer>().material.mainTextureOffset = speed * Time.time; //obtemos sua propriedade material,para poder alterar o Offset pelo script,usamos a prpriedade mainTextureOffset para modificar a textura principal,usamos Time.time para criar o efeito,já que é um contador incrementado desde o inicio do jogo
    }
}
