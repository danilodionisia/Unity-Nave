﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireEnemy : MonoBehaviour
{
    public float interval = 2; //variavel define de quanto em quanto tempo o inimigo atira
    public GameObject bulletPrefab; //variavel de onde vai o prefab da bala
    //public GameObject bulletPosition; //variavel informa de onde a bala deve sair
    public GameObject bulletLeft;
    public GameObject bulletRight;
    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("Fire", interval, interval);//função de loop que faz o inimigo atirar
    }

    // Update is called once per frame
    void Fire()//metodo para instanciar o tiro
    {
       // Instantiate(bulletPrefab, bulletPosition.transform.position, Quaternion.identity);
        Instantiate(bulletPrefab, bulletLeft.transform.position, Quaternion.identity);
        Instantiate(bulletPrefab, bulletRight.transform.position, Quaternion.identity);
    }
    
}
