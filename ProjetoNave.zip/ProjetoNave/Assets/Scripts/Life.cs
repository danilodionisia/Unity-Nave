﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Life : MonoBehaviour
{

    public static int life;
    public int numberlifes;

    public Image[] lifes;
    public Sprite fullLife;
    public Sprite emptyLife;

    private void Start()
    {
        life = 3;
    }

    private void Update()
    {
        
        switch (life)
        {
            case 3:

                lifes[0].sprite = fullLife;
                lifes[1].sprite = fullLife;
                lifes[2].sprite = fullLife;

                break;

            case 2:

                lifes[0].sprite = fullLife;
                lifes[1].sprite = fullLife;
                lifes[2].sprite = emptyLife;

                break;

            case 1:

                lifes[0].sprite = fullLife;
                lifes[1].sprite = emptyLife;
                lifes[2].sprite = emptyLife;

                break;

            case 0:

                lifes[0].sprite = emptyLife;
                lifes[1].sprite = emptyLife;
                lifes[2].sprite = emptyLife;

                Destroy(gameObject);

                break;
        
                
        }

        /*
        for (int i = 0; i < lifes.Length; i++)
        {
            if(i < life)
            {
                lifes[i].sprite = fullLife;
            }
            else
            {
                lifes[i].sprite = emptyLife;
            }


            if(i < numberlifes)
            {
                lifes[i].enabled = true;
            }
            else
            {
                lifes[i].enabled = false;
            }
        }*/
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {

        /*if (life < 1)
        {
            Destroy(gameObject);

        }*/

    }
}
