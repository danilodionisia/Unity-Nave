﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Border : MonoBehaviour
{
    void OnCollisionEnter2D(Collision2D collision) //variavel usada para notificar sempre que houver colissao com a borda
    {
        if (collision.gameObject.name != "PlayerShip")// se houver colisao com um objeto de nome diferente de PlayerShip
        {
            Destroy(collision.gameObject);            // destoi este objeto
        }
    }
}
